package com.watchhub.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.watchhub.App

/** Phone ke notifications (WhatsApp, SMS, etc.) watch par bhejta hai. */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.isOngoing) return
        val e = sbn.notification.extras
        val title = e.getString(Notification.EXTRA_TITLE) ?: return
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        App.ble.pushMessage(sbn.packageName, title, text)
    }
}
