package com.watchhub.ble

/** Har brand ke liye ek driver. Naya watch = naya driver, baaki app same rehti hai. */
interface WatchDriver {
    val name: String
    fun matches(deviceName: String?): Boolean
    fun onConnected(io: WatchIO)
    fun syncTime(io: WatchIO)
    fun pushMessage(io: WatchIO, app: String, title: String, text: String)
    fun incomingCall(io: WatchIO, who: String)
    fun setAlarm(io: WatchIO, id: Int, hour: Int, minute: Int, enabled: Boolean)
    fun requestBattery(io: WatchIO)
}

interface WatchIO {
    fun write(service: String, characteristic: String, data: ByteArray)
    fun read(service: String, characteristic: String)
}

/**
 * MKWatch / MoYoung-type driver. UUID aur command bytes PLACEHOLDER hain:
 * asli values aapki watch ke HCI snoop log se bharni hain.
 */
class MkWatchDriver : WatchDriver {
    override val name = "MKWatch"
    private val SERVICE = "0000fee7-0000-1000-8000-00805f9b34fb"   // TODO verify
    private val WRITE   = "0000fec7-0000-1000-8000-00805f9b34fb"   // TODO verify
    override fun matches(deviceName: String?) =
        deviceName?.contains("mk", true) == true || deviceName?.contains("watch", true) == true
    override fun onConnected(io: WatchIO) { syncTime(io); requestBattery(io) }
    override fun syncTime(io: WatchIO) { /* TODO: time packet */ }
    override fun pushMessage(io: WatchIO, app: String, title: String, text: String) {
        io.write(SERVICE, WRITE, byteArrayOf(0x01) + title.take(20).toByteArray() + text.take(60).toByteArray())
    }
    override fun incomingCall(io: WatchIO, who: String) { io.write(SERVICE, WRITE, byteArrayOf(0x02) + who.take(20).toByteArray()) }
    override fun setAlarm(io: WatchIO, id: Int, hour: Int, minute: Int, enabled: Boolean) {
        io.write(SERVICE, WRITE, byteArrayOf(0x03, id.toByte(), hour.toByte(), minute.toByte(), if (enabled) 1 else 0))
    }
    override fun requestBattery(io: WatchIO) { io.read("0000180f-0000-1000-8000-00805f9b34fb", "00002a19-0000-1000-8000-00805f9b34fb") }
}
