package com.watchhub

import android.app.Application
import com.watchhub.ble.BleManager

class App : Application() {
    companion object { lateinit var ble: BleManager }
    override fun onCreate() { super.onCreate(); ble = BleManager(this) }
}
